<?php

class HuffmanCompressor extends AbstractCompressor
{
    private array $huffmanTable = [];

    /**
     * Compresse un fichier en utilisant l'algorithme de Huffman.
     */
    public function compress(string $input, string $output): bool
    {
        $data = $this->readFile($input);
        if ($data === null) {
            return false;
        }

        // Générer l'arbre de Huffman
        $frequency = $this->calculateFrequency($data);
        $tree = $this->buildHuffmanTree($frequency);
        $this->generateHuffmanTable($tree);

        // Encoder les données
        $encodedData = $this->encodeData($data);
        $metadata = json_encode(['table' => $this->huffmanTable]);
        $compressedData = $metadata . "\n===SEPARATOR===\n" . $encodedData;

        return $this->writeFile($output, $compressedData);
    }

    /**
     * Décompresse un fichier compressé avec Huffman.
     */
    public function decompress(string $input, string $output): bool
    {
        $data = $this->readFile($input);
        if ($data === null) {
            echo "Erreur : impossible de lire le fichier d'entrée.\n";
            return false;
        }

        // Séparer les métadonnées et les données encodées
        $parts = explode("\n===SEPARATOR===\n", $data, 2);
        if (count($parts) < 2) {
            echo "Erreur : données corrompues ou mal formatées.\n";
            return false;
        }

        [$metadata, $encodedData] = $parts;

        // Décoder les métadonnées
        $metadataDecoded = json_decode($metadata, true);
        if ($metadataDecoded === null || !isset($metadataDecoded['table'])) {
            echo "Erreur : métadonnées invalides ou inexistantes.\n";
            return false;
        }
        $this->huffmanTable = $metadataDecoded['table'];

        // Décoder les données
        $decodedData = $this->decodeData($encodedData);
        return $this->writeFile($output, $decodedData);
    }


    // Utilitaires pour Huffman
    private function calculateFrequency(string $data): array
    {
        $frequency = [];
        foreach (str_split($data) as $char) {
            $frequency[$char] = ($frequency[$char] ?? 0) + 1;
        }
        return $frequency;
    }

    private function buildHuffmanTree(array $frequency): object
    {
        $queue = new SplPriorityQueue();
        foreach ($frequency as $char => $freq) {
            $queue->insert((object)['char' => $char, 'freq' => $freq, 'left' => null, 'right' => null], -$freq);
        }

        while ($queue->count() > 1) {
            $left = $queue->extract();
            $right = $queue->extract();
            $queue->insert((object)[
                'char' => null,
                'freq' => $left->freq + $right->freq,
                'left' => $left,
                'right' => $right,
            ], -($left->freq + $right->freq));
        }

        return $queue->extract();
    }

    private function generateHuffmanTable(object $node, string $code = ''): void
    {
        if ($node->char !== null) {
            $this->huffmanTable[$node->char] = $code;
            return;
        }

        $this->generateHuffmanTable($node->left, $code . '0');
        $this->generateHuffmanTable($node->right, $code . '1');
    }

    private function encodeData(string $data): string
    {
        $encoded = '';
        foreach (str_split($data) as $char) {
            $encoded .= $this->huffmanTable[$char];
        }
        return $encoded;
    }

    private function decodeData(string $encodedData): string
    {
        $reversedTable = array_flip($this->huffmanTable);
        $decoded = '';
        $buffer = '';
        foreach (str_split($encodedData) as $bit) {
            $buffer .= $bit;
            if (isset($reversedTable[$buffer])) {
                $decoded .= $reversedTable[$buffer];
                $buffer = '';
            }
        }
        return $decoded;
    }
}
